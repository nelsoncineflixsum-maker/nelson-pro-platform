// Nelson Pro - Main Application JavaScript
class NelsonProApp {
    constructor() {
        this.apiBaseUrl = '/api';
        this.currentUser = null;
        this.currentTheme = 'gold';
        this.init();
    }

    init() {
        // Check authentication
        if (!this.checkAuth()) {
            window.location.href = '/frontend/pages/login.html';
            return;
        }

        // Load user data
        this.loadUserData();

        // Setup event listeners
        this.setupEventListeners();

        // Load theme preference
        this.loadTheme();

        // Initialize components
        this.initializeDashboard();
    }

    checkAuth() {
        const token = localStorage.getItem('token');
        if (!token) return false;

        // Validate token expiry
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            const expiry = payload.exp * 1000;

            if (Date.now() >= expiry) {
                this.logout();
                return false;
            }

            return true;
        } catch (error) {
            console.error('Token validation error:', error);
            return false;
        }
    }

    loadUserData() {
        const userStr = localStorage.getItem('user');
        if (userStr) {
            this.currentUser = JSON.parse(userStr);
            this.updateUserInterface();
        } else {
            this.fetchUserData();
        }
    }

    async fetchUserData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/user/profile`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.currentUser = data.user;
                localStorage.setItem('user', JSON.stringify(data.user));
                this.updateUserInterface();
            } else if (response.status === 401) {
                this.logout();
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    }

    updateUserInterface() {
        if (!this.currentUser) return;

        // Update user name
        const userNameElements = document.querySelectorAll('[data-user-name]');
        userNameElements.forEach(el => {
            el.textContent = this.currentUser.name || 'Usuário';
        });

        // Update user email
        const userEmailElements = document.querySelectorAll('[data-user-email]');
        userEmailElements.forEach(el => {
            el.textContent = this.currentUser.email || '';
        });

        // Update user avatar
        const avatarElements = document.querySelectorAll('.user-avatar');
        avatarElements.forEach(avatar => {
            if (this.currentUser.avatar) {
                avatar.innerHTML = `<img src="${this.currentUser.avatar}" alt="${this.currentUser.name}">`;
            } else {
                const initials = this.getInitials(this.currentUser.name);
                avatar.textContent = initials;
            }
        });

        // Update admin UI if user is admin
        if (this.currentUser.role === 'admin') {
            document.querySelectorAll('.admin-only').forEach(el => {
                el.style.display = 'block';
            });
        }
    }

    getInitials(name) {
        if (!name) return 'U';
        const parts = name.split(' ');
        if (parts.length >= 2) {
            return (parts[0][0] + parts[1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    }

    setupEventListeners() {
        // Mobile menu toggle
        const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
        if (mobileMenuToggle) {
            mobileMenuToggle.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Logout button
        const logoutBtns = document.querySelectorAll('[data-logout]');
        logoutBtns.forEach(btn => {
            btn.addEventListener('click', () => this.logout());
        });

        // Theme switcher
        const themeSwitchers = document.querySelectorAll('[data-theme]');
        themeSwitchers.forEach(switcher => {
            switcher.addEventListener('click', (e) => {
                const theme = e.currentTarget.dataset.theme;
                this.changeTheme(theme);
            });
        });

        // Navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                navLinks.forEach(l => l.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });

        // Search functionality
        const searchInput = document.querySelector('.search-bar input');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.handleSearch(e.target.value);
                }, 300);
            });
        }

        // Click outside sidebar to close on mobile
        document.addEventListener('click', (e) => {
            const sidebar = document.querySelector('.sidebar');
            const mobileToggle = document.querySelector('.mobile-menu-toggle');

            if (sidebar && sidebar.classList.contains('active')) {
                if (!sidebar.contains(e.target) && !mobileToggle.contains(e.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    }

    toggleMobileMenu() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
    }

    loadTheme() {
        const savedTheme = localStorage.getItem('theme') || 'gold';
        this.changeTheme(savedTheme);
    }

    changeTheme(theme) {
        const themes = {
            gold: { primary: '#d4af37', secondary: '#b8941f' },
            green: { primary: '#00ff88', secondary: '#00cc6f' },
            blue: { primary: '#3b82f6', secondary: '#2563eb' },
            purple: { primary: '#a855f7', secondary: '#9333ea' },
            red: { primary: '#ef4444', secondary: '#dc2626' }
        };

        if (themes[theme]) {
            document.documentElement.style.setProperty('--primary-gold', themes[theme].primary);
            this.currentTheme = theme;
            localStorage.setItem('theme', theme);

            // Update active theme indicator
            document.querySelectorAll('[data-theme]').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.theme === theme);
            });
        }
    }

    handleSearch(query) {
        if (!query || query.length < 2) {
            this.clearSearchResults();
            return;
        }

        console.log('Searching for:', query);
        // Implement search logic here
        // This would typically search through courses, lessons, etc.
    }

    clearSearchResults() {
        // Clear search results UI
        console.log('Search cleared');
    }

    logout() {
        // Clear all stored data
        localStorage.removeItem('token');
        localStorage.removeItem('user');

        // Redirect to login
        window.location.href = '/frontend/pages/login.html';
    }

    initializeDashboard() {
        // Load dashboard data
        this.loadDashboardStats();
        this.loadRecentCourses();
        this.loadProgress();
    }

    async loadDashboardStats() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/user/stats`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.updateStats(data.stats);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
            // Use default stats if API fails
            this.updateStats({
                coursesEnrolled: 0,
                coursesCompleted: 0,
                hoursWatched: 0,
                certificatesEarned: 0
            });
        }
    }

    updateStats(stats) {
        const statsMap = {
            'courses-enrolled': stats.coursesEnrolled || 0,
            'courses-completed': stats.coursesCompleted || 0,
            'hours-watched': stats.hoursWatched || 0,
            'certificates': stats.certificatesEarned || 0
        };

        Object.keys(statsMap).forEach(key => {
            const element = document.querySelector(`[data-stat="${key}"]`);
            if (element) {
                this.animateNumber(element, 0, statsMap[key], 1000);
            }
        });
    }

    animateNumber(element, start, end, duration) {
        const range = end - start;
        const increment = range / (duration / 16);
        let current = start;

        const timer = setInterval(() => {
            current += increment;
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                current = end;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current);
        }, 16);
    }

    async loadRecentCourses() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/user/courses`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.renderCourses(data.courses);
            }
        } catch (error) {
            console.error('Error loading courses:', error);
        }
    }

    renderCourses(courses) {
        const container = document.querySelector('.course-grid');
        if (!container) return;

        if (!courses || courses.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                    <h3>Nenhum curso encontrado</h3>
                    <p>Comece sua jornada explorando nossos cursos disponíveis</p>
                    <button class="btn btn-primary">Explorar Cursos</button>
                </div>
            `;
            return;
        }

        container.innerHTML = courses.map(course => this.createCourseCard(course)).join('');
    }

    createCourseCard(course) {
        const progress = course.progress || 0;
        return `
            <div class="course-card" data-course-id="${course.id}">
                <div class="course-thumbnail">
                    ${course.thumbnail ? `<img src="${course.thumbnail}" alt="${course.title}">` : ''}
                    ${course.status ? `<span class="course-status">${course.status}</span>` : ''}
                </div>
                <div class="course-content">
                    <div class="course-meta">
                        <span class="course-category">${course.category || 'Geral'}</span>
                        <span class="course-duration">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            ${course.duration || '0h'}
                        </span>
                    </div>
                    <h3 class="course-title">${course.title}</h3>
                    <p class="course-description">${course.description || ''}</p>
                    ${progress > 0 ? `
                        <div class="course-progress">
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${progress}%"></div>
                            </div>
                            <span class="progress-text">${progress}% completo</span>
                        </div>
                    ` : ''}
                    <div class="course-footer">
                        <div class="course-instructor">
                            <div class="instructor-avatar"></div>
                            <span class="instructor-name">${course.instructor || 'Nelson Pro'}</span>
                        </div>
                        <a href="#" class="btn btn-ghost">
                            ${progress > 0 ? 'Continuar' : 'Começar'}
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    async loadProgress() {
        // Load user progress data
        try {
            const response = await fetch(`${this.apiBaseUrl}/user/progress`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.updateProgress(data.progress);
            }
        } catch (error) {
            console.error('Error loading progress:', error);
        }
    }

    updateProgress(progress) {
        // Update progress charts and indicators
        console.log('Progress data:', progress);
    }

    // Notification system
    showNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            background: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4444' : '#d4af37'};
            color: #050505;
            border-radius: 12px;
            font-weight: 600;
            z-index: 9999;
            animation: slideInRight 0.3s ease-out;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => notification.remove(), 300);
        }, duration);
    }

    // API helper method
    async apiRequest(endpoint, options = {}) {
        const token = localStorage.getItem('token');

        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        };

        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };

        try {
            const response = await fetch(`${this.apiBaseUrl}${endpoint}`, mergedOptions);

            if (response.status === 401) {
                this.logout();
                throw new Error('Unauthorized');
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Request failed');
            }

            return data;
        } catch (error) {
            console.error('API request error:', error);
            throw error;
        }
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new NelsonProApp();
});

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes slideOutRight {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);
