// Nelson Pro - Authentication System
class AuthManager {
    constructor() {
        this.apiBaseUrl = '/api/auth';
        this.init();
    }

    init() {
        // Check if already authenticated on protected pages
        if (this.isAuthPage()) {
            if (this.isAuthenticated()) {
                window.location.href = '/frontend/pages/dashboard.html';
            }
        }

        // Setup form listeners
        this.setupEventListeners();
    }

    isAuthPage() {
        const currentPath = window.location.pathname;
        return currentPath.includes('login.html') || currentPath.includes('register.html');
    }

    setupEventListeners() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Register form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }

        // Password toggle
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => this.togglePassword(e));
        });

        // Remember me
        const rememberMe = localStorage.getItem('rememberMe');
        if (rememberMe) {
            const emailInput = document.getElementById('email');
            if (emailInput) {
                emailInput.value = rememberMe;
                const rememberCheckbox = document.getElementById('remember');
                if (rememberCheckbox) rememberCheckbox.checked = true;
            }
        }
    }

    async handleLogin(e) {
        e.preventDefault();

        const form = e.target;
        const submitBtn = form.querySelector('button[type="submit"]');
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const remember = document.getElementById('remember')?.checked || false;

        // Validate
        if (!this.validateEmail(email)) {
            this.showAlert('Por favor, insira um email válido', 'error');
            return;
        }

        if (!password || password.length < 6) {
            this.showAlert('A senha deve ter no mínimo 6 caracteres', 'error');
            return;
        }

        // Set loading state
        this.setLoading(submitBtn, true);

        try {
            const response = await fetch(`${this.apiBaseUrl}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Save token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));

                // Save email if remember me is checked
                if (remember) {
                    localStorage.setItem('rememberMe', email);
                } else {
                    localStorage.removeItem('rememberMe');
                }

                this.showAlert('Login realizado com sucesso!', 'success');

                // Redirect to dashboard
                setTimeout(() => {
                    window.location.href = '/frontend/pages/dashboard.html';
                }, 1000);
            } else {
                this.showAlert(data.message || 'Erro ao fazer login', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showAlert('Erro ao conectar com o servidor', 'error');
        } finally {
            this.setLoading(submitBtn, false);
        }
    }

    async handleRegister(e) {
        e.preventDefault();

        const form = e.target;
        const submitBtn = form.querySelector('button[type="submit"]');
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const terms = document.getElementById('terms')?.checked || false;

        // Validate
        if (!name || name.length < 3) {
            this.showAlert('O nome deve ter no mínimo 3 caracteres', 'error');
            return;
        }

        if (!this.validateEmail(email)) {
            this.showAlert('Por favor, insira um email válido', 'error');
            return;
        }

        if (!password || password.length < 6) {
            this.showAlert('A senha deve ter no mínimo 6 caracteres', 'error');
            return;
        }

        if (password !== confirmPassword) {
            this.showAlert('As senhas não coincidem', 'error');
            return;
        }

        if (!terms) {
            this.showAlert('Você precisa aceitar os termos de uso', 'error');
            return;
        }

        // Set loading state
        this.setLoading(submitBtn, true);

        try {
            const response = await fetch(`${this.apiBaseUrl}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ name, email, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Save token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));

                this.showAlert('Cadastro realizado com sucesso!', 'success');

                // Redirect to dashboard
                setTimeout(() => {
                    window.location.href = '/frontend/pages/dashboard.html';
                }, 1000);
            } else {
                this.showAlert(data.message || 'Erro ao criar conta', 'error');
            }
        } catch (error) {
            console.error('Register error:', error);
            this.showAlert('Erro ao conectar com o servidor', 'error');
        } finally {
            this.setLoading(submitBtn, false);
        }
    }

    togglePassword(e) {
        const button = e.currentTarget;
        const input = button.previousElementSibling;

        if (input.type === 'password') {
            input.type = 'text';
            button.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                </svg>
            `;
        } else {
            input.type = 'password';
            button.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
            `;
        }
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    showAlert(message, type = 'info') {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert');
        if (existingAlert) {
            existingAlert.remove();
        }

        // Create new alert
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} show`;
        alert.textContent = message;

        // Insert at the top of the form
        const form = document.querySelector('.auth-form');
        if (form) {
            form.insertBefore(alert, form.firstChild);

            // Auto remove after 5 seconds
            setTimeout(() => {
                alert.classList.remove('show');
                setTimeout(() => alert.remove(), 300);
            }, 5000);
        }
    }

    setLoading(button, isLoading) {
        if (isLoading) {
            button.classList.add('loading');
            button.disabled = true;
            button.dataset.originalText = button.textContent;
            button.textContent = '';
        } else {
            button.classList.remove('loading');
            button.disabled = false;
            button.textContent = button.dataset.originalText || 'Entrar';
        }
    }

    isAuthenticated() {
        const token = localStorage.getItem('token');
        if (!token) return false;

        // Check if token is expired (basic check)
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            const expiry = payload.exp * 1000;
            return Date.now() < expiry;
        } catch (error) {
            return false;
        }
    }

    getUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    }

    getToken() {
        return localStorage.getItem('token');
    }

    logout() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/frontend/pages/login.html';
    }

    // Social login handlers (placeholder for future implementation)
    async loginWithGoogle() {
        this.showAlert('Login com Google em breve!', 'info');
    }

    async loginWithFacebook() {
        this.showAlert('Login com Facebook em breve!', 'info');
    }
}

// Initialize auth manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.authManager = new AuthManager();
});

// Social login button handlers
function handleGoogleLogin() {
    window.authManager.loginWithGoogle();
}

function handleFacebookLogin() {
    window.authManager.loginWithFacebook();
}
