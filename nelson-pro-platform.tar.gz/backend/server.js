const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');
const path = require('path');

// Importar rotas
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');

dotenv.config();

const app = express();

// Middlewares
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, '../frontend')));

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);

// Rota principal - servir index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Conectar ao MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/nelson-pro-platform')
    .then(() => {
        console.log('✅ Conectado ao MongoDB com sucesso!');
    })
    .catch((err) => {
        console.error('❌ Erro ao conectar ao MongoDB:', err.message);
        console.log('⚠️  Continuando em modo de desenvolvimento (dados em memória)');
    });

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`\n🎬 NELSON PRO PLATFORM - Servidor rodando!`);
    console.log(`📡 URL: http://localhost:${PORT}`);
    console.log(`🔐 Sistema de autenticação: ATIVO`);
    console.log(`💾 Banco de dados: MongoDB\n`);
});

module.exports = app;
