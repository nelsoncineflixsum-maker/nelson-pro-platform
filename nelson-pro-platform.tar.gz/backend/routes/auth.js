const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Gerar token JWT
const generateToken = (userId) => {
    return jwt.sign(
        { userId },
        process.env.JWT_SECRET || 'nelson_pro_secret_key_2026',
        { expiresIn: '7d' } // Token válido por 7 dias
    );
};

// ROTA: Cadastro de usuário
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Validação básica
        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Todos os campos são obrigatórios.'
            });
        }

        // Verificar se email já existe
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'Este email já está cadastrado.'
            });
        }

        // Criar novo usuário
        const user = new User({
            name,
            email,
            password,
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=d4af37&color=000&size=200`
        });

        await user.save();

        // Gerar token
        const token = generateToken(user._id);

        // Enviar token no cookie
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 7 * 24 * 60 * 60 * 1000 // 7 dias
        });

        res.status(201).json({
            success: true,
            message: 'Cadastro realizado com sucesso!',
            user: user.toJSON(),
            token
        });
    } catch (error) {
        console.error('Erro no cadastro:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao criar conta. Tente novamente.',
            error: error.message
        });
    }
});

// ROTA: Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validação
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email e senha são obrigatórios.'
            });
        }

        // Buscar usuário
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Email ou senha incorretos.'
            });
        }

        // Verificar senha
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Email ou senha incorretos.'
            });
        }

        // Atualizar último login
        user.lastLogin = Date.now();
        await user.save();

        // Gerar token
        const token = generateToken(user._id);

        // Enviar token no cookie
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 7 * 24 * 60 * 60 * 1000 // 7 dias
        });

        res.json({
            success: true,
            message: 'Login realizado com sucesso!',
            user: user.toJSON(),
            token
        });
    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao fazer login. Tente novamente.'
        });
    }
});

// ROTA: Logout
router.post('/logout', auth, (req, res) => {
    res.clearCookie('token');
    res.json({
        success: true,
        message: 'Logout realizado com sucesso!'
    });
});

// ROTA: Verificar autenticação
router.get('/me', auth, (req, res) => {
    res.json({
        success: true,
        user: req.user
    });
});

module.exports = router;
