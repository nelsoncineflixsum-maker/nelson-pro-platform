const express = require('express');
const User = require('../models/User');
const { auth, isAdmin } = require('../middleware/auth');
const bcrypt = require('bcryptjs');

const router = express.Router();

// ROTA: Atualizar perfil
router.put('/profile', auth, async (req, res) => {
    try {
        const { name, email, avatar, themeColor } = req.body;

        const user = await User.findById(req.user._id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado.'
            });
        }

        // Atualizar campos
        if (name) user.name = name;
        if (email) {
            // Verificar se email já existe
            const emailExists = await User.findOne({ email, _id: { $ne: user._id } });
            if (emailExists) {
                return res.status(400).json({
                    success: false,
                    message: 'Este email já está em uso.'
                });
            }
            user.email = email;
        }
        if (avatar) user.avatar = avatar;
        if (themeColor) user.themeColor = themeColor;

        await user.save();

        res.json({
            success: true,
            message: 'Perfil atualizado com sucesso!',
            user: user.toJSON()
        });
    } catch (error) {
        console.error('Erro ao atualizar perfil:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao atualizar perfil.',
            error: error.message
        });
    }
});

// ROTA: Alterar senha
router.put('/change-password', auth, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Senha atual e nova senha são obrigatórias.'
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'A nova senha deve ter no mínimo 6 caracteres.'
            });
        }

        const user = await User.findById(req.user._id);

        // Verificar senha atual
        const isMatch = await user.comparePassword(currentPassword);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Senha atual incorreta.'
            });
        }

        // Atualizar senha
        user.password = newPassword;
        await user.save();

        res.json({
            success: true,
            message: 'Senha alterada com sucesso!'
        });
    } catch (error) {
        console.error('Erro ao alterar senha:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao alterar senha.'
        });
    }
});

// ROTA: Listar todos os usuários (ADMIN)
router.get('/all', auth, isAdmin, async (req, res) => {
    try {
        const users = await User.find().select('-password').sort({ createdAt: -1 });

        res.json({
            success: true,
            count: users.length,
            users
        });
    } catch (error) {
        console.error('Erro ao listar usuários:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao listar usuários.'
        });
    }
});

// ROTA: Deletar usuário (ADMIN)
router.delete('/:id', auth, isAdmin, async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado.'
            });
        }

        res.json({
            success: true,
            message: 'Usuário deletado com sucesso!'
        });
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao deletar usuário.'
        });
    }
});

// ROTA: Tornar usuário admin (ADMIN)
router.put('/make-admin/:id', auth, isAdmin, async (req, res) => {
    try {
        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado.'
            });
        }

        user.isAdmin = true;
        await user.save();

        res.json({
            success: true,
            message: 'Usuário promovido a administrador!',
            user: user.toJSON()
        });
    } catch (error) {
        console.error('Erro ao promover usuário:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao promover usuário.'
        });
    }
});

module.exports = router;
