const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Middleware de autenticação
const auth = async (req, res, next) => {
    try {
        // Pegar token do cookie ou header
        const token = req.cookies.token || req.header('Authorization')?.replace('Bearer ', '');

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Acesso negado. Token não fornecido.'
            });
        }

        // Verificar token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'nelson_pro_secret_key_2026');

        // Buscar usuário
        const user = await User.findById(decoded.userId).select('-password');

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Usuário não encontrado.'
            });
        }

        req.user = user;
        next();
    } catch (error) {
        console.error('Erro na autenticação:', error.message);
        res.status(401).json({
            success: false,
            message: 'Token inválido ou expirado.'
        });
    }
};

// Middleware para verificar se é admin
const isAdmin = (req, res, next) => {
    if (!req.user.isAdmin) {
        return res.status(403).json({
            success: false,
            message: 'Acesso negado. Apenas administradores.'
        });
    }
    next();
};

module.exports = { auth, isAdmin };
